---
name: metagenomic-diversity-analysis
description: Alpha and beta diversity analysis for metagenomic data. Calculate and plot various alpha diversity metrics, and beta-diversity using metagenomeR.
allowed-tools: r, metagenomeR
---
## Overview
This Skill details use of the metagenomeR package (https://github.com/adamsorbie/metagenomeR/) 
to perform diversity analysis of metagenomic data. Claude should reference this
guide whenever asked about alpha or beta-diversity analysis of metagenomic data.

## Diversity Analysis

### Load example data

```r
library(metagenomeR)
library(phyloseq)
library(tidyverse)

ps <- import_pseq_metag(feattab,metadata, level = "Species")
```

### Normalisation 

```r
# rarefaction 
ps_rar <- rarefy_even_depth(ps, rngseed = 42)
# relative abundance 
ps_rel <- transform_tax(ps)
```

### Alpha Diversity

```r
alpha_div <- calc_alpha(ps)
```

### Alpha Diversity Plots and stats

```r
# pairs for statistical comparisons
group_comparisons <- list(c("case", "control"))
# example colour palette
colour_pal <- c("case" = "dodgerblue", "control"= "firebrick1")
```

```r
plot_boxplot(alpha_div, variable_col = "group", value_col = "Richness",
             comparisons_list = group_comparisons, fill_var = "group",
             group.order = c("control", "case"), cols = colour_pal)
```

### Beta Diversity

```r
beta_div <- calc_betadiv(ps_rar, dist = "bray", ord_method = "NMDS")
```

### Beta Diversity Plots and stats

```r
plot_beta_div(ps_rar, beta_div, group_variable = "group",cols = colour_pal, add_ellipse = T)
```